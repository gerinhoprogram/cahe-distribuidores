<div class='banner-topo'>
    <div class='linha'>
        <div class="colunas lg-12 md-12 pq-12 logo">
            <img src="core/imagens/logo.png" alt="Cahe - Produtos" title='Cahe - Produtos' width="150">
        </div>
        <div class='colunas lg-12 md-12 pq-12'>
            <h1>SEJA UM DISTRIBUIDOR CAHE</h1>
            <p>Produtos direto de fábrica com qualidade comprovada. Descubra os benefícios em ser um distribuidor Cahe Produtos.</p>
        </div>
    </div>
</div>